// component.js
export default {
  name: 'WelcomeCard',
  props: {
    title: {
      type: String,
      default: '欢迎使用！'
    },
    content: {
      type: String,
      default: '这是一个由插件提供的欢迎卡片。'
    },
    color: {
      type: String,
      default: '#4CAF50'
    }
  },
  template: `
    <div class="welcome-card" :style="{ borderLeftColor: color }">
      <h3>{{ title }}</h3>
      <p>{{ content }}</p>
    </div>
  `
};